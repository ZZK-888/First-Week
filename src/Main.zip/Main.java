import java.util.Scanner;
class Input{
public static void main(String[] arg) {
    Scanner in= new Scanner(System.in ) ;
    String m;
do {

    System.out.println("请输入平时成绩");
    int a = in.nextInt();
    System.out.println("请输入期中成绩");
    int b = in.nextInt();
    System.out.println("请输入期末成绩");
    int c = in.nextInt();
    double end = a*0.2 + b*0.3 + c*0.5;
    System.out.println("最终成绩为：" + end);

    if (end <= 60) {
        System.out.println("勇敢俊枭，不怕困难");
    } else {
        System.out.println("就这？还没我卷");
    }


    System.out.println("try again?(yes,no)");
    m = in.next();
}while (m.equals("yes"));

}
}